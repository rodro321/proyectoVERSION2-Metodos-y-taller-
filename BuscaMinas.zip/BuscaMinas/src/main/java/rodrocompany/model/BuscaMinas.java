/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package rodrocompany.model;

/**
 *
 * @author win
 */
public class BuscaMinas {

    public static void main(String[] args) {
        System.out.println("Hello World!");

               
        Modelo model = new Modelo();
        model.mostrar();
        //model.generarMinas();
        model.mostrar();
       
    }

}
